let xhr = new XMLHttpRequest();
xhr.open("get","./user.json");
xhr.responseType = "json";

let btn = document.getElementById("btn");
let display1 = document.getElementById("display");
let tbody = document.getElementById("tbody");

btn.addEventListener("mouseover",function(){
    btn.style["background-color"] = "#E5B36E";
});
btn.addEventListener("mouseout",function(){
    btn.style["background-color"] = "orange";
});
btn.addEventListener("click",function(){
    xhr.onload = function(){
        btn.remove();
        display1.style.display = "block";
        
        for(let i = 0; i < this.response.length; i++){
            let tr = document.createElement("tr");
            let th1 = document.createElement("th");
            let th2 = document.createElement("th");

            th1.textContent = this.response[i].name;
            th2.textContent = this.response[i].old;

            tr.appendChild(th1);
            tr.appendChild(th2);
            tbody.appendChild(tr);

            th1.style.height = "50px";
            th1.style["text-align"] = "left";
            th2.style.height = "50px";
            th2.style["text-align"] = "left";
            if(i % 2 == 0){
                tr.style["background-color"] = "lightgray";
            }else{
                tr.style["background-color"] = "gray";
            }
        }
    }   
    xhr.send();
});
