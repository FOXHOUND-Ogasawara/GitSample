package 実施済みテスト.kadai01_Ans;

public class Square extends Rectangle {
    public Square(int sideLength) {
        super(sideLength, sideLength);
    }
}
