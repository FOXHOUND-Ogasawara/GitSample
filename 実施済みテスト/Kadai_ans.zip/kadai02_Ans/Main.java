package 実施済みテスト.kadai02_Ans;

public class Main {
    public static void main(String[] args) {
        Car car = new Car(60);
        Bicycle bicycle = new Bicycle(20);

        car.accelerate(20);
        bicycle.accelerate(10);
    }
}
