public class Animal {
    private String name;

    public Animal(String name){
        this.name = name;
    }

    public String getName(){
        return this.name;
    }

    public void bark(){
        System.out.println(this.name + "は鳴きます");
    }
}
