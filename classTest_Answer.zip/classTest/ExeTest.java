public class ExeTest {
    public static void main(String[] args) {
        Animal[] animals = new Animal[2];

        animals[0] = new Cat("猫");
        animals[1] = new Dog("犬");

        for (int i = 0; i < animals.length; i++) {
            animals[i].bark();
        }
    }
}
